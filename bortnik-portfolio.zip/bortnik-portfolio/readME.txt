Чтобы запустить приложение нужно установить папку Node Modules 

После установки написать в терминале npm start

В нулевой директории лежит папка README.md в которой описаны команды 

////////////////////////////////////////////////////////////////////////

To run the application, you need to install the Node Modules

After the installation, write npm start in terminal 

The zero directory contains the README.md folder, which describes the commands