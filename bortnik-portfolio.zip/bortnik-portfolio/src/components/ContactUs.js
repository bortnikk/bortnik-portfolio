import React from 'react'

function ContactUs() {
  return (
   <section className="nonModifiedPages">
      <h1>Contact Us</h1>
   </section>
  )
}

export default ContactUs