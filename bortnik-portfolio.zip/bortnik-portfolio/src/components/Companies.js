import React from 'react'

import mainStartups from '../Data/mainStartupsData'

function Companies() {
  return (
      <section className='stylesStart'>
        <h3 className='heading'>Findtrend make +1000 Startup grow</h3>
        <div className='startUpContainer'>
            {mainStartups.map(startup => <div className='imgContainer'><img className='stylesImg' src={startup.startUpsImg} alt={startup.id} key={startup.id}/></div>)}
        </div>
      </section>
  )
}

export default Companies