import React from 'react'

function About() {
  return (
   <section className="nonModifiedPages">
      <h1>About</h1>
   </section>
  )
}

export default About