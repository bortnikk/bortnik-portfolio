import React from 'react'

function JoinUs() {
  return (
     <section className="joinUs">
        <h6>
           Join us on email for
        <br/>
        <span>more trending topics</span>
        </h6>
        <button className="joinUsBtn">Join Now </button>
    </section>
  )
}

export default JoinUs