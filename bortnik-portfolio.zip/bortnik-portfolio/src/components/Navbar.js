import React from 'react'

import { NavLink , Link } from 'react-router-dom'

import navLogo from '../images/logo.svg'
import icon from '../images/iPhone 11 Pro/icon.svg'

function Navbar() {

      const [navMob,setNavMob] = React.useState(false)
      function showNavMenu() {
        setNavMob(prevState => !prevState)
      }
      const navMobMenu =
      <div className='navMobMenuStyles'>
        <ul className="navUlMob">
          <li className='navUlMobli'>
            <NavLink to='/About' className="navLinksMob">About</NavLink>
          </li>
          <li className='navUlMobli'>
            <NavLink to='/Info' className="navLinksMob">How it work</NavLink>
          </li>
          <li className='navUlMobli'>
            <NavLink to='/Pricing' className="navLinksMob">Pricing</NavLink>
          </li>
          <li className='navUlMobli'>
            <NavLink to='/Solution' className="navLinksMob">Solution</NavLink>
          </li>
          <li className='navUlMobli'>
            <NavLink to='/Features' className="navLinksMob">Features</NavLink>
          </li>
        </ul>
        <div className="nav-registrationMob">
          <button className="nav-login"><Link to='/Login' className="navButtonsMobLog">Login</Link></button>
          <button className="nav-register"><Link to='/Register' className="navButtonsMob">Register</Link></button>
        </div>
      </div>
  
  const parallels = <div className="navMobileBtn">
                      <span className="btnNavSpanFirst"></span>
                      <span className="btnNavSpanSecond"></span>
                    </div>
  
  const cross = <div className="navMobileBtnCross">
                  <img src={icon} alt='lala'/>
                </div>


  return (
    <nav>
      <NavLink to='/' className="navLogo"><img alt="navLogo" src={navLogo} /><p>Findtrend</p></NavLink>
      <ul className="navUl">
        <li>
          <NavLink to='/About' className="navLinks">About</NavLink>
        </li>
        <li>
          <NavLink to='/Info' className="navLinks">How it work</NavLink>
        </li>
        <li>
          <NavLink to='/Pricing' className="navLinks">Pricing</NavLink>
        </li>
        <li>
          <NavLink to='/Solution' className="navLinks">Solution</NavLink>
        </li>
        <li>
          <NavLink to='/Features' className="navLinks">Features</NavLink>
        </li>
      </ul>
      <div className="nav-registration">
        <button className="nav-login"><Link to='/Login' className="navButtons">Login</Link></button>
        <button className="nav-register"><Link to='/Register' className="navButtons">Register</Link></button>
      </div>
      <button onClick={showNavMenu} className="navMobileBtn">
      {navMob ? cross : parallels}
      </button>
      {navMob ? navMobMenu : ''}
    </nav>
  )
}

export default Navbar