import React from 'react'

function Pricing() {
  return (
   <section className="nonModifiedPages">
      <h1>Pricing</h1>
   </section>
  )
}

export default Pricing