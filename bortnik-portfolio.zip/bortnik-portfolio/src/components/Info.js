import React from 'react'

function Info() {
  return (
   <section className="nonModifiedPages">
      <h1>Info</h1>
   </section>
  )
}

export default Info