import React from 'react'

function Register() {
  return (
   <section className="nonModifiedPages">
      <h1>Register</h1>
   </section>
  )
}

export default Register