import React from 'react'
import offersData from "../Data/offersData"
import offersDataYearly from "../Data/offersDataYearly"

function Deals() {
   
   const [booleanSwitchState,setBooleanSwitchState] = React.useState(true)

   function onChange() {
      setBooleanSwitchState(prevState => !prevState)
   }

   const offers = offersData.map(offer => <div key={offer.id} className='offer__container'>
         <h6 className='offer__heading'>{offer.heading}</h6>
         <small className='offer__subheading'>{offer.subHeading}</small>
         <span className='offer__line'></span>
         <div className='offer__price'>{offer.price}<span className='offer__span'>{offer.month}</span></div>
         {offer.text}
         <buttom className='offer__btn'>
            <a href={offer.url} className='offer__link'>{offer.freeTrial}</a>
         </buttom>
      </div>
   )
 
   const offersYearly = offersDataYearly.map(offer => <div key={offer.id} className='offer__container'>
         <h6 className='offer__heading'>{offer.heading}</h6>
         <small className='offer__subheading'>{offer.subHeading}</small>
         <span className='offer__line'></span>
         <div className='offer__price'>{offer.price}<span className='offer__span'>{offer.month}</span></div>
         {offer.text}
         <buttom className='offer__btn'>
            <a href={offer.url} className='offer__link'>{offer.freeTrial}</a>
         </buttom>
      </div>
   )

   const dealsStylings = {
      color: booleanSwitchState ? '#fff' : '#A8FF35',
   }

   return (
      <section className='deals'>
         <h5>Get your best deal</h5>
         <div className='subsPeriod'>
            <p>Monthly</p>

               <div className="Switch" >
                  
                  <input className="react-switch-checkbox" id={`react-switch-new`} type="checkbox" onClick={onChange}/>

                  <label
                  className="react-switch-label"
                  htmlFor={`react-switch-new`}
                  >

                  <span className={`react-switch-button`} />
                     
                  </label>

               </div>

            <p className='Yearly' style={dealsStylings}>Yearly</p>

         </div>

         <div className='subsOffers'>
            {booleanSwitchState ? offers : offersYearly}
         </div>

      </section>
   )
}

export default Deals