import React from 'react'
import { Link } from 'react-router-dom'
import elonTab from '../images/tab--elonmask.png'

function OpenNewTabs() {
  return (
     <section className="OpenNewTabs">
         <Link to='/' name="OpenNewTabsLink"/>
         <h2 className="tabs-heading">Open new tabs is sh*t</h2>
         <div className="OpenNewTabs--content">
           <img src={elonTab} alt='elon tab' className='elonTab'/>
         </div>
         <p className="OpenNewTabs--paragraph">A solution for your browser tabs and dont make your device get slower over time. Get ease and faster to discover a trend with just one tab.</p>
     </section>
  )
}

export default OpenNewTabs