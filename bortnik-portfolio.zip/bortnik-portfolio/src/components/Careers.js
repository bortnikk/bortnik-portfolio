import React from 'react'

function Careers() {
  return (
   <section className="nonModifiedPages">
      <h1>Careers</h1>
   </section>
  )
}

export default Careers