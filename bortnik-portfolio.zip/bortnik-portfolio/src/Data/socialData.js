import icon1 from '../images/icon1.png';
import icon2 from '../images/icon2.png';
import icon3 from '../images/icon3.png';
import icon4 from '../images/icon4.png';
import icon5 from '../images/icon5.png';
import icon6 from '../images/icon6.png';
import icon7 from '../images/icon7.png';
import icon8 from '../images/icon8.png';

const socialData = [
   {
      id: '1',
      socialImg: icon1,
      route:'https://www.facebook.com/'
   },
   {
      id: '2',
      socialImg: icon2,
      route:'https://www.twitter.com'
   },
   {
      id: '3',
      socialImg: icon3,
      route:'https://www.nba.com'
   },
   {
      id: '4',
      socialImg: icon4,
      route:'https://www.pinterest.com'
   },
   {
      id: '5',
      socialImg: icon5,
      route:'https://www.movie.com'
   },
   {
      id: '6',
      socialImg: icon6,
      route:'https://www.reddit.com'
   },
   {
      id: '7',
      socialImg: icon7,
      route:'https://www.vk.com'
   },
   {
      id: '8',
      socialImg: icon8,
      route:'https://www.linkedin.com'
   },
]

export default socialData