import React from 'react'

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Home from './components/Home';
import Navbar from './components/Navbar';
import Footer from './components/Footer'

import Features from './components/Features'
import Solution from './components/Solution'
import Pricing from './components/Pricing'
import Info from './components/Info'
import About from './components/About'
import PrivacyPolicy from './components/PrivacyPolicy'
import TermsAndConditions from './components/TermsAndConditions'
import ContactUs from './components/ContactUs'
import Careers from './components/Careers'
import Register from './components/Register'
import Login from './components/Login'

function App() {
  return (
    <Router>
      
      <div className="App">
        
      <Navbar />
        
        <div className="content-container">

          <Routes>
            <Route path="/" element={<Home />} />
          </Routes>

          <Routes>
            <Route path="/Features" element={<Features />} />
          </Routes>

          <Routes>
            <Route path="/Solution" element={<Solution />} />
          </Routes>

          <Routes>
            <Route path="/Pricing" element={<Pricing />} />
          </Routes>

          <Routes>
            <Route path="/Info" element={<Info />} />
          </Routes>

          <Routes>
            <Route path="/About" element={<About />} />
          </Routes>

          <Routes>
            <Route path="/Login" element={<Login />} />
          </Routes>

          <Routes>
            <Route path="/Register" element={<Register />} />
          </Routes>

          <Routes>
            <Route path="/PrivacyPolicy" element={<PrivacyPolicy />} />
          </Routes>

          <Routes>
            <Route path="/TermsAndConditions" element={<TermsAndConditions />} />
          </Routes>

          <Routes>
            <Route path="/ContactUs" element={<ContactUs />} />
          </Routes>

          <Routes>
            <Route path="/Careers" element={<Careers />} />
          </Routes>

        </div>

        <Footer />

      </div>

    </Router>
  )
}

export default App