import React from 'react'

function Solution() {
  return (
   <section className="nonModifiedPages">
      <h1>Solution</h1>
   </section>
  )
}

export default Solution