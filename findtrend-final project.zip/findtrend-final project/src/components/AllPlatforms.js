import React from 'react'

import { TwitterTimelineEmbed , TwitterTweetEmbed} from 'react-twitter-embed';

import socialData from '../Data/socialData'

const socials = socialData.map(social => {
   return <a href={social.route} key={social.id} className="socialImg--container"><img src={social.socialImg} alt='socials' className='socialImg'/></a>
})

function AllPlatforms() {
  return (
   <section className='AllPlatforms'>
         <h4 className='AllPlatforms--heading'>
            All platform connect to Findtrend
        </h4>
        <div className="all-platform__socials">
           {socials}
        </div>
        <div className="all-platform__tweets">
           <div className='twitter'>
            <TwitterTimelineEmbed
                     sourceType="profile"
                     screenName="elonmusk"
               options={{
                  height: 1000,
                  width: 1160,
                  padding:5
               }}
               />
           </div>
           <div className="twitter__mob">
            <TwitterTweetEmbed 
                 tweetId={'1518194746052726786'}
               />
            <TwitterTweetEmbed
                  tweetId={'1517197510778884097'}
               />
            <TwitterTweetEmbed
                  tweetId={'1518027837797769218'}
               />
           </div>
        </div>
        <button className="allPlatforms--button">
           <a href="https://www.twitter.com">View More Trend</a>
        </button>
   </section>
  )
}

export default AllPlatforms