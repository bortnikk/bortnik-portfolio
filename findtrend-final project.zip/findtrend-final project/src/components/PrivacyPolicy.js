import React from 'react'

function PrivacyPolicy() {
  return (
   <section className="nonModifiedPages">
      <h1>Privacy Policy</h1>
   </section>
  )
}

export default PrivacyPolicy