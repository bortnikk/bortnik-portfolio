import React from 'react'

function Login() {
  return (
   <section className="nonModifiedPages">
      <h1>Login</h1>
   </section>
  )
}

export default Login