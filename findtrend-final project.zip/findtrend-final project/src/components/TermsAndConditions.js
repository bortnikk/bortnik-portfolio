import React from 'react'

function TermsAndConditions() {
  return (
   <section className="nonModifiedPages">
      <h1>Terms And Conditions</h1>
   </section>
  )
}

export default TermsAndConditions