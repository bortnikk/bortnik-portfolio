import React from 'react'

import Header from './Header'
import OpenNewTabs from './OpenNewTabs'
import Description from './Description'
import Companies from './Companies'
import AllPlatforms from './AllPlatforms'
import Deals from './Deals'
import JoinUs from './JoinUs'

function Home() {
  return (
    <main>
      <Header />
      <OpenNewTabs />
      <Description />
      <Companies />
      <AllPlatforms />
      <Deals />
      <JoinUs />
    </main>
  )
}

export default Home