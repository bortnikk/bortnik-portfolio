import React from 'react'

import logo from '../images/footer-logo.png'

import { Link } from 'react-router-dom'

function Footer() {
  return (
    <footer>
      <div className="footer-logo">
        <Link to='/' className="footerLogo"><img alt="footerLogo" src={logo} /><p>Findtrend</p></Link>
      </div>
      <div className="footer-links">
        <ul className="footerUl">
          <li>
            <Link to='/PrivacyPolicy' className="footerLinks">Privacy Policy</Link>
          </li>
          <li>
            <Link to='/TermsAndConditions' className="footerLinks">Terms and Conditions</Link>
          </li>
          <li>
            <Link to='/ContactUs' className="footerLinks">Contact Us</Link>
          </li>
          <li>
            <Link to='/Careers' className="footerLinks">Careers</Link>
          </li>
        </ul>
      </div>
    </footer>
  )
}

export default Footer