import React from 'react'

function Features() {
  return (
     <section className="nonModifiedPages">
        <h1>Features</h1>
     </section>
  )
}

export default Features