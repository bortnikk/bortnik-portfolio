import React from 'react'

// import headerPicture from '../images/btn-hero-socmed2.png'

import headerPicture1 from '../images/1.svg'
import headerPicture2 from '../images/2.svg'
import headerPicture3 from '../images/3.svg'
import headerPicture4 from '../images/4.svg'

function Header() {
  return (
    <header>
      <h1>
        Minimize your tabs.
        <br />
        Find the trends!
      </h1>
      <p>
        Don’t let your computer memories consumes all of those browser tabs. 
        <br/>
        Findtrend  let you gathers all of your favorite website into one place.
      </p>
      <button>
        <a href="#OpenNewTabsLink" className='headerButton'>Get Started 🔥</a>
      </button>
      <div className="headerPicture">
        <div className="headerPicture__container"><img src={headerPicture1} alt='headerPicture' className='headerImg__solo' /></div>
        <div className="headerPicture__container"><img src={headerPicture2} alt='headerPicture' className='headerImg__solo2'/></div>
        <div className="headerPicture__container"><img src={headerPicture3} alt='headerPicture' className='headerImg__solo'/></div>
        <div className="headerPicture__container"><img src={headerPicture4} alt='headerPicture' className='headerImg__solo2' /></div>
      </div>
    </header>
  )
}

export default Header