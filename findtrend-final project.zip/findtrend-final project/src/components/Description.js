import React from 'react'

const findtrend = {
  backgroundColor:'#A8FF35',
}

function Description() {
  return (
     <section className="descriptionMaxWidth">
         <p className='desriptionParagraph'>
           <span style={findtrend}>Findtrend</span> helps you to increase your productivity and reduce your computer's memory load,
               <span className='descriptionSpanStyles'> an application that can fulfill your daily browsing needs.</span>
         </p>
     </section>
  )
}

export default Description