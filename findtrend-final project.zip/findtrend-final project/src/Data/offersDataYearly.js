const offersDataYearly = [
   {
      id:1,
      heading: 'Personal',
      subHeading: 'Special first packet for all',
      price: '$86',
      month: '/Year',
      freeTrial: 'Start Free Trial',
      url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      text: <ul className="offersUl">
         <li className='offersLi'>Up to 5 page each group</li>
         <li className='offersLi'>Up to 10 group page</li>
         <li className='offersLi'>5 Days group page saved</li>
      </ul>
   },
   {
      id:2,
      heading: 'Regular',
      subHeading: 'Recommended for personal pro',
      price: '$216',
      month: '/Year',
      freeTrial: 'Start Free Trial',
      url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      text: <ul className="offersUl">
         <li className='offersLi'>Up to 15 page each group</li>
         <li className='offersLi'>Download page up to 20 page</li>
         <li className='offersLi'>Up to 10 group page</li>
         <li className='offersLi'>15 Days group page saved</li>
      </ul>
   },
   {
      id:3,
      heading: 'Premium',
      subHeading: 'Packet for Startup & Company',
      price:'$518',
      month: '/Year',
      freeTrial: 'Start Free Trial',
      url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      text:<ul className="offersUl">
         <li className='offersLi'>Unlimited group pages</li>
         <li className='offersLi'>Unlimited download page</li>
         <li className='offersLi'>Unlimited page each group</li>
         <li className='offersLi'>Customize sorting group pages</li>
         <li className='offersLi'>Customize group page name</li>
         <li className='offersLi'>30 Days group page saved</li>
      </ul>
   },
]

export default offersDataYearly