import img1 from '../images/img1.png'
import img2 from '../images/img2.png'
import img3 from '../images/img3.png'
import img4 from '../images/img4.png'
import img5 from '../images/img5.png'
import img6 from '../images/img6.png'
import img7 from '../images/img7.png'
import img8 from '../images/img8.png'
import img9 from '../images/img9.png'
import img10 from '../images/img10.png'
import img11 from '../images/img11.png'
import img12 from '../images/img12.png'
import img13 from '../images/img13.png'
import img14 from '../images/img14.png'
import img15 from '../images/img15.png'
import img16 from '../images/img16.png'

const mainStartups = [
   {
      id: '1',
      startUpsImg: img1,
   },
   {
      id: '2',
      startUpsImg: img2,
   },
   {
      id: '3',
      startUpsImg: img3,
   },
   {
      id: '4',
      startUpsImg: img4,
   },
   {
      id: '5',
      startUpsImg: img5,
   },
   {
      id: '6',
      startUpsImg: img6,
   },
   {
      id: '7',
      startUpsImg: img7,
   },
   {
      id: '8',
      startUpsImg: img8,
   },
   {
      id: '9',
      startUpsImg: img9,
   },
   {
      id: '10',
      startUpsImg: img10,
   },
   {
      id: '11',
      startUpsImg: img11,
   },
   {
      id: '12',
      startUpsImg: img12,
   },
   {
      id: '13',
      startUpsImg: img13,
   },
   {
      id: '14',
      startUpsImg: img14,
   },
   {
      id: '15',
      startUpsImg: img15,
   },
   {
      id: '16',
      startUpsImg: img16,
   },
]

export default mainStartups